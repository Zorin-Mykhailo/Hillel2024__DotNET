﻿namespace EfCoreExamples.ContextV1.Entities
{
    public abstract record BaseEntity
    {
        public int Id { get; set; }
    }
}
