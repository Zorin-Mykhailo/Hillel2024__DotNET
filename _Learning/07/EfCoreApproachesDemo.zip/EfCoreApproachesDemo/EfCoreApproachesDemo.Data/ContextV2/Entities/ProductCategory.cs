﻿//using System.ComponentModel.DataAnnotations;

//namespace EfCoreExamples.ContextV2.Entities
//{
//    public record ProductCategory : BaseEntity
//    {
//		[Required]
//		public int ProductId { get; set; }

//		[Required]
//		public int CategoryId { get; set; }

//        public virtual Product? Product { get; set; }

//        public virtual Category? Category { get; set; }
//    }
//}
