﻿namespace DemoConsoleApp
{
    public static class Program
    {
        public static void Main()
        {
            Console.WriteLine("It Works!");
        }
    }
}