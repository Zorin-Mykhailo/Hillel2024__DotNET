export interface Registration {
  userId: string;
  userName: string;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
}
