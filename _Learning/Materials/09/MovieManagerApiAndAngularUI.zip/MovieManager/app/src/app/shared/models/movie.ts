export interface Movie {
  movieId: number;
  title: string;
  description: string;
  releaseDate: string;
}
