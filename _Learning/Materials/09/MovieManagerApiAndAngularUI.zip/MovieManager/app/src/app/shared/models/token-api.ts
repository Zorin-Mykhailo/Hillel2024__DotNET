export interface TokenApi {
  accessToken: string;
  refreshToken: string;
}
