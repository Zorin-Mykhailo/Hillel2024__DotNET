﻿namespace MovieManager.Contract.Responses
{
    public class TokenApiResponse
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
    }
}
