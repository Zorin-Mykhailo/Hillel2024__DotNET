﻿namespace Domain.Products;

public record Money(string Currency, decimal Amount);