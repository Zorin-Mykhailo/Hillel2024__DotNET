﻿namespace Domain.Products;

public record ProductId(Guid Value);
