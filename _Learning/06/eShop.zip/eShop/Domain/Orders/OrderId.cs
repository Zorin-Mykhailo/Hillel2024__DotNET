﻿namespace Domain.Orders;

public record OrderId(Guid Value);
