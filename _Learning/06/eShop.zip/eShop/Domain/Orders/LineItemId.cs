﻿namespace Domain.Orders;

public record LineItemId(Guid Value);