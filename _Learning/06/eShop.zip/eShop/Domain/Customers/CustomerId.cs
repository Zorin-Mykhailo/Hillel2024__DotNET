﻿namespace Domain.Customers;

public record CustomerId(Guid Value);