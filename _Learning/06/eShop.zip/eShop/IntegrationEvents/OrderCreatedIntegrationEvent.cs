﻿namespace IntegrationEvents;

public record OrderCreatedIntegrationEvent(Guid OrderId);