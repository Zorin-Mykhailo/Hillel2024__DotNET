﻿namespace DesignPatternsExamples.Factory.Abstract_Factory.Interfaces
{
    public interface IBaseProduct
    {
        string Name { get; }
    }
}
