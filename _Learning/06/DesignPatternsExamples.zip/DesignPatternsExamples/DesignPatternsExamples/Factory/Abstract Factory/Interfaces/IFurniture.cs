﻿namespace DesignPatternsExamples.Factory.Abstract_Factory.Interfaces
{
    public interface IFurniture
    {
        IBaseProduct Create();
    }
}
