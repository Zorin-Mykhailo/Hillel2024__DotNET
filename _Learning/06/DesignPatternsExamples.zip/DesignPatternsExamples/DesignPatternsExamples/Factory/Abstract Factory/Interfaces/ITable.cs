﻿namespace DesignPatternsExamples.Factory.Abstract_Factory.Interfaces
{
    public interface ITable : IBaseProduct
    {
        string GetPurpose();
    }
}
