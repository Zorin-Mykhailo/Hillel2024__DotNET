﻿namespace DesignPatternsExamples.Factory.Abstract_Factory.Interfaces
{
    public interface ISofa : IBaseProduct
    {
        string GetPurpose(string description);
    }
}
