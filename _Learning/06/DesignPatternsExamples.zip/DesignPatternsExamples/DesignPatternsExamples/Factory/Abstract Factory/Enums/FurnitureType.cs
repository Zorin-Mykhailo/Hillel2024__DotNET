﻿namespace DesignPatternsExamples.Factory.Abstract_Factory.Enums
{
    public enum FurnitureType
    {
        Armchair,

        Sofa,

        Table
    }
}
