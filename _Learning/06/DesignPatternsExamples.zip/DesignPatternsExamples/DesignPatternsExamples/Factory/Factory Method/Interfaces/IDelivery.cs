﻿namespace DesignPatternsExamples.Factory.Factory_Method.Interfaces
{
    public interface IDelivery
    {
        string GetDeliveryType();
    }
}
