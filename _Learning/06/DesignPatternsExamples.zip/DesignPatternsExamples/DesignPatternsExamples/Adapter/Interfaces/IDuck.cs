﻿namespace DesignPatternsExamples.Adapter.Interfaces
{
    public interface IDuck
    {
        void Quack();

        void Fly();
    }
}
