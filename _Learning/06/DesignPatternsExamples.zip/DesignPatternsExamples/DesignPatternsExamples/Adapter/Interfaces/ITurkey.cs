﻿namespace DesignPatternsExamples.Adapter.Interfaces
{
    public interface ITurkey
    {
        void Gobble();

        void Fly();
    }
}
