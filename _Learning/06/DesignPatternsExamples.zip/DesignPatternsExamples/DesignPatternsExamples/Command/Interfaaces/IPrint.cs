﻿namespace DesignPatternsExamples.Command.Interfaaces
{
    public interface IPrinter
    {
        public void Print(string Text);
    }
}
