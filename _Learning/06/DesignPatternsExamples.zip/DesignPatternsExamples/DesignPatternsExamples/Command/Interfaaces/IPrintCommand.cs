﻿namespace DesignPatternsExamples.Command.Interfaaces
{
    public interface IPrintCommand
    {
        public void ExecutePrint(string Text);
    }
}
