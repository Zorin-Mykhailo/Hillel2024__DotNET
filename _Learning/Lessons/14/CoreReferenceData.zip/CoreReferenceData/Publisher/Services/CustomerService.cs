﻿using DotNetCore.CAP;
using Publisher.Data;
using Publisher.Models;
using System.Text.Json;

namespace Publisher.Services
{
	public interface ICustomerService
	{
		Task<bool> AddCustomer(CustomerInsert order);
	}

	public class CustomerService : ICustomerService
	{
		private readonly ServiceDbContext _dbContext;
		private readonly ICapPublisher _capPublisher;

		public CustomerService(ServiceDbContext dbContext, ICapPublisher capPublisher)
		{
			_dbContext = dbContext;
			_capPublisher = capPublisher;
		}

		public async Task<bool> AddCustomer(CustomerInsert customerInsert)
		{
			Customer customer = new Customer
			{
				FirstName = customerInsert.FirstName,
				LastName = customerInsert.LastName,
				MobilNumber = customerInsert.MobilNumber,
			};

			await _dbContext.AddAsync(customer);
			await _dbContext.SaveChangesAsync();
			var content = JsonSerializer.Serialize(customer);
			await _capPublisher.PublishAsync("CustomerAdded", content);
			return true;
		}
	}
}
