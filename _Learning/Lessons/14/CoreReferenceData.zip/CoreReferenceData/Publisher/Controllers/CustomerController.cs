﻿using Microsoft.AspNetCore.Mvc;
using Publisher.Models;

namespace Publisher.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class CustomerController : ControllerBase
	{

		private readonly ICustomerService _customerService;


		public CustomerController(ICustomerService customerService)
		{
			_customerService = customerService;

		}

		[HttpPost]
		public async Task<IActionResult> Post([FromBody] CustomerInsert customer)
		{
			try
			{
				return Ok(await _customerService.AddCustomer(customer));
			}
			catch (Exception ex)
			{

				throw;
			}
		}
	}
}
