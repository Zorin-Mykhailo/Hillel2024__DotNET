﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CoreReferenceData.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class DirectorController : ControllerBase
	{
		private List<string> directors = new();

		public DirectorController()
		{
			directors = new List<string> { "Vasya", "Petya", "Anton" };
		}

		[HttpGet]
		public IActionResult GetDirectors()
		{
			return Ok(directors);
		}

		[HttpPost]
		public IActionResult PostDirectors([FromBody] string directorName)
		{
			directors.Add(directorName);
			return Ok(directors);
		}
	}
}
