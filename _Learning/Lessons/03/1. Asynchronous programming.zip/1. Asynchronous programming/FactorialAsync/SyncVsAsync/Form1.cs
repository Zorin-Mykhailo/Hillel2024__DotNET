using System.Diagnostics;

namespace SyncVsAsync
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Height = 120;
        }

        private void RunWithoutBtn_Click(object sender, EventArgs e)
        {
            try
            {
                RunWithoutBtn.Enabled = false;

                if (GetValue(out var time))
                {
                    Reset(time: time);
                    Text = "Running calculation WITHOUT await. Try moving this form.";
                    var result = LongCalculation(time, new Progress<int>(this.ReportProgress));
                    Message($"The result is {result}");
                }
            }
            finally
            {
                RunWithoutBtn.Enabled = true;
            }
        }

        private async void RunWithBtn_Click(object sender, EventArgs e)
        {
            try
            {
                RunWithBtn.Enabled = false;
                Height = 200;

                if (GetValue(out var time))
                {
                    Reset(time: time);
                    Text = "Running calculation WITH await. Try moving this form.";
                    var result = await Task.Run(() => LongCalculation(time, new Progress<int>(ReportProgress)));
                    Message($"The result is {result}");
                }
            }
            finally
            {
                Height = 120;
                RunWithBtn.Enabled = true;
            }
        }

        private static int LongCalculation(TimeSpan time, IProgress<int> report)
        {
            var stopwatch = Stopwatch.StartNew();
            var summary = 0;
            var lastReport = 0;

            do
            {
                summary += 1;
                var current = (int)stopwatch.Elapsed.TotalSeconds;

                if (current > lastReport)
                {
                    report.Report(current);
                    lastReport = current;
                }
            } while (stopwatch.Elapsed < time);

            report.Report(0);

            return summary;
        }

        private bool GetValue(out TimeSpan time)
        {
            const int seconds = 10;
            time = TimeSpan.FromSeconds(seconds);

            return true;
        }

        private void ReportProgress(int value)
        {
            progressBar1.Value = value;
        }

        private void Reset(TimeSpan time)
        {
            progressBar1.Minimum = default;
            progressBar1.Maximum = 1 + (int)time.TotalSeconds;
            progressBar1.Value = default;
        }

        private void Message(string? text)
        {
            MessageBox.Show(text, "Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}