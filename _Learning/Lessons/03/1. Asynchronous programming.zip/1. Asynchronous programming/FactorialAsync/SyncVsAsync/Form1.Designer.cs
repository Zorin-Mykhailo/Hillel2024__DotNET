﻿namespace SyncVsAsync
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            RunWithoutBtn = new Button();
            RunWithBtn = new Button();
            progressBar1 = new ProgressBar();
            label3 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(191, 19);
            label1.TabIndex = 0;
            label1.Text = "Calculate without async-await";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(261, 9);
            label2.Name = "label2";
            label2.Size = new Size(170, 19);
            label2.TabIndex = 1;
            label2.Text = "Calculate with async-await";
            // 
            // RunWithoutBtn
            // 
            RunWithoutBtn.BackColor = SystemColors.ActiveCaption;
            RunWithoutBtn.ForeColor = Color.Black;
            RunWithoutBtn.Location = new Point(12, 31);
            RunWithoutBtn.Name = "RunWithoutBtn";
            RunWithoutBtn.Size = new Size(191, 36);
            RunWithoutBtn.TabIndex = 2;
            RunWithoutBtn.Text = "Run";
            RunWithoutBtn.UseVisualStyleBackColor = false;
            RunWithoutBtn.Click += RunWithoutBtn_Click;
            // 
            // RunWithBtn
            // 
            RunWithBtn.BackColor = Color.LimeGreen;
            RunWithBtn.Location = new Point(237, 31);
            RunWithBtn.Name = "RunWithBtn";
            RunWithBtn.Size = new Size(194, 36);
            RunWithBtn.TabIndex = 3;
            RunWithBtn.Text = "Run";
            RunWithBtn.UseVisualStyleBackColor = false;
            RunWithBtn.Click += RunWithBtn_Click;
            // 
            // progressBar1
            // 
            progressBar1.Location = new Point(12, 102);
            progressBar1.Name = "progressBar1";
            progressBar1.Size = new Size(419, 34);
            progressBar1.TabIndex = 4;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(139, 80);
            label3.Name = "label3";
            label3.Size = new Size(133, 19);
            label3.TabIndex = 5;
            label3.Text = "Calculation progress";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(443, 149);
            Controls.Add(label3);
            Controls.Add(progressBar1);
            Controls.Add(RunWithBtn);
            Controls.Add(RunWithoutBtn);
            Controls.Add(label2);
            Controls.Add(label1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sync VS Async";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button RunWithoutBtn;
        private Button RunWithBtn;
        private ProgressBar progressBar1;
        private Label label3;
    }
}