﻿namespace CopyFilesWPF.View
{
    public interface IMainWindowView
    {
        MainWindow MainWindowView { get; }
    }
}
