namespace ClassicControls
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>

	public partial class EmbeddedFont : System.Windows.Window
	{

		public EmbeddedFont()
		{
			InitializeComponent();

			//MessageBox.Show(tst.FontFamily.BaseUri.ToString());
		}

	}
}