namespace Content
{
	/// <summary>
	/// Interaction logic for ButtonWithViewboxContent.xaml
	/// </summary>

	public partial class ButtonWithViewboxContent : System.Windows.Window
	{

		public ButtonWithViewboxContent()
		{
			InitializeComponent();
		}

	}
}