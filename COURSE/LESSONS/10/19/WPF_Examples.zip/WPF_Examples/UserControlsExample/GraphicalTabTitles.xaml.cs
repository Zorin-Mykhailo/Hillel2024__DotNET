namespace Content
{
	/// <summary>
	/// Interaction logic for GraphicalTabTitles.xaml
	/// </summary>

	public partial class GraphicalTabTitles : System.Windows.Window
	{

		public GraphicalTabTitles()
		{
			InitializeComponent();
		}

	}
}