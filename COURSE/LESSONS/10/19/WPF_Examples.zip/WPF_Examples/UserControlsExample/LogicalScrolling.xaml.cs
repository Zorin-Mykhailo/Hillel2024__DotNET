namespace Content
{
	/// <summary>
	/// Interaction logic for LogicalScrolling.xaml
	/// </summary>

	public partial class LogicalScrolling : System.Windows.Window
	{

		public LogicalScrolling()
		{
			InitializeComponent();
		}

	}
}