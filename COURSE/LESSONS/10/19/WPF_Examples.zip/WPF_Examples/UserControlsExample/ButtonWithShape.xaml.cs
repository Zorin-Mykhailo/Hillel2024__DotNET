namespace Content
{
	/// <summary>
	/// Interaction logic for ButtonWithShape.xaml
	/// </summary>

	public partial class ButtonWithShape : System.Windows.Window
	{

		public ButtonWithShape()
		{
			InitializeComponent();
		}

	}
}