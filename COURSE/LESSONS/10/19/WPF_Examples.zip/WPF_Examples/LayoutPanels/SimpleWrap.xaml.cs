using System.Windows;

namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for SimpleWrap.xaml
	/// </summary>

	public partial class SimpleWrap : Window
	{

		public SimpleWrap()
		{
			InitializeComponent();
		}

	}
}