using System.Windows;

namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for SimpleDock.xaml
	/// </summary>

	public partial class SimpleDock : Window
	{

		public SimpleDock()
		{
			InitializeComponent();
		}
	}
}