using System.Windows;

namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for BasicDialogBox.xaml
	/// </summary>

	public partial class BasicDialogBox : Window
	{

		public BasicDialogBox()
		{
			InitializeComponent();
		}

	}
}