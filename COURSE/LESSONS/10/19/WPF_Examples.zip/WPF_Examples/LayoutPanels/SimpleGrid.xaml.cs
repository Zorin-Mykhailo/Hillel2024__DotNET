namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for SimpleGrid.xaml
	/// </summary>

	public partial class SimpleGrid : System.Windows.Window
	{

		public SimpleGrid()
		{
			InitializeComponent();
		}
	}
}