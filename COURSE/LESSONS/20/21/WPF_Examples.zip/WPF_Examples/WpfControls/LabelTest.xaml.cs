namespace ClassicControls
{
	/// <summary>
	/// Interaction logic for LabelTest.xaml
	/// </summary>

	public partial class LabelTest : System.Windows.Window
	{

		public LabelTest()
		{
			InitializeComponent();
		}


	}
}