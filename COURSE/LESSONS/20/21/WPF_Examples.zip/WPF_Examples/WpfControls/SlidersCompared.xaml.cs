namespace ClassicControls
{
	/// <summary>
	/// Interaction logic for SlidersCompared.xaml
	/// </summary>

	public partial class SlidersCompared : System.Windows.Window
	{

		public SlidersCompared()
		{
			InitializeComponent();
		}

	}
}