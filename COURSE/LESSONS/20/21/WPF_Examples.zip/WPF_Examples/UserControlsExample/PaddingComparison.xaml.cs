namespace Content
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>

	public partial class PaddingComparison : System.Windows.Window
	{

		public PaddingComparison()
		{
			InitializeComponent();
		}

	}
}