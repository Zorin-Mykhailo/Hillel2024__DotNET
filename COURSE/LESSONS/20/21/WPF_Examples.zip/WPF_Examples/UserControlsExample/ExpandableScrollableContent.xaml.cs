namespace Content
{
	/// <summary>
	/// Interaction logic for ExpandableScrollableContent.xaml
	/// </summary>

	public partial class ExpandableScrollableContent : System.Windows.Window
	{

		public ExpandableScrollableContent()
		{
			InitializeComponent();
		}

	}
}