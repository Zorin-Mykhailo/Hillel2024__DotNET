﻿namespace BindingToClass
{
	public class Person
	{
		public string Surname
		{
			get
			{
				return "Petrov";
			}
		}
	}
}
