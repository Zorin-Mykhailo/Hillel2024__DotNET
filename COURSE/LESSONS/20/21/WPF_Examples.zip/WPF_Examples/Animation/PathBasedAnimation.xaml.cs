namespace Animation
{
	/// <summary>
	/// Interaction logic for PathBasedAnimation.xaml
	/// </summary>

	public partial class PathBasedAnimation : System.Windows.Window
	{

		public PathBasedAnimation()
		{
			InitializeComponent();
		}

	}
}