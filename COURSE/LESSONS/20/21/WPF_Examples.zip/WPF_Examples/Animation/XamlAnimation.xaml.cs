namespace Animation
{
	/// <summary>
	/// Interaction logic for XAMLAnimation.xaml
	/// </summary>

	public partial class XamlAnimation : System.Windows.Window
	{

		public XamlAnimation()
		{
			InitializeComponent();
		}

	}
}