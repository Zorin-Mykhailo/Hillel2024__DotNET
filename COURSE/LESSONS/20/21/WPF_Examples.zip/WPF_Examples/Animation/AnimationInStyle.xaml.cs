namespace Animation
{
	/// <summary>
	/// Interaction logic for AnimationInStyle.xaml
	/// </summary>

	public partial class AnimationInStyle : System.Windows.Window
	{

		public AnimationInStyle()
		{
			InitializeComponent();
		}

	}
}