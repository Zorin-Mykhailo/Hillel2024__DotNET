namespace Animation
{
	/// <summary>
	/// Interaction logic for MultiPartTemplates.xaml
	/// </summary>

	public partial class AnimationInTemplate : System.Windows.Window
	{

		public AnimationInTemplate()
		{
			InitializeComponent();
		}

	}
}