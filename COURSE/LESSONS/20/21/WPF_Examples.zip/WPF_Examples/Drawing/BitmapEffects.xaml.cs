namespace Drawing
{
	/// <summary>
	/// Interaction logic for BitmapEffects.xaml
	/// </summary>

	public partial class BitmapEffects : System.Windows.Window
	{

		public BitmapEffects()
		{
			InitializeComponent();
		}

	}
}