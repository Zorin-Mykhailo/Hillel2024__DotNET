namespace Drawing
{
	/// <summary>
	/// Interaction logic for FillModes.xaml
	/// </summary>

	public partial class FillModes : System.Windows.Window
	{

		public FillModes()
		{
			InitializeComponent();
		}

	}
}