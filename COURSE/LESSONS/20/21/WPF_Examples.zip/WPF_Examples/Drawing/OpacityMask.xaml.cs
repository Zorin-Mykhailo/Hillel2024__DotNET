namespace Drawing
{
	/// <summary>
	/// Interaction logic for Reflection.xaml
	/// </summary>

	public partial class OpacityMask : System.Windows.Window
	{

		public OpacityMask()
		{
			InitializeComponent();
		}

	}
}