namespace Drawing
{
	/// <summary>
	/// Interaction logic for CombiningShapes.xaml
	/// </summary>

	public partial class CombiningShapes : System.Windows.Window
	{

		public CombiningShapes()
		{
			InitializeComponent();
		}

	}
}