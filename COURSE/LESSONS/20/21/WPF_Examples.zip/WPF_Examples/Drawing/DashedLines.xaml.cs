namespace Drawing
{
	/// <summary>
	/// Interaction logic for DashedLines.xaml
	/// </summary>

	public partial class DashedLines : System.Windows.Window
	{

		public DashedLines()
		{
			InitializeComponent();
		}

	}
}