namespace Drawing
{
	/// <summary>
	/// Interaction logic for LineCaps.xaml
	/// </summary>

	public partial class LineCaps : System.Windows.Window
	{

		public LineCaps()
		{
			InitializeComponent();
		}

	}
}