namespace Drawing
{
	/// <summary>
	/// Interaction logic for VisualBrush.xaml
	/// </summary>

	public partial class VisualBrush : System.Windows.Window
	{

		public VisualBrush()
		{
			InitializeComponent();
		}

	}
}