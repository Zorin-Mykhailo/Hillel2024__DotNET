﻿using System.Windows;

namespace RoutedEvents
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}

}
