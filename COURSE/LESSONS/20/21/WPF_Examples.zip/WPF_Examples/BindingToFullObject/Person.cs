﻿namespace BindingToFullObject
{
	public class Person
	{
		public override string ToString()
		{
			return "User Person";
		}
	}
}
