namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for SplitWindow.xaml
	/// </summary>

	public partial class SplitWindow : System.Windows.Window
	{

		public SplitWindow()
		{
			InitializeComponent();
		}

	}
}