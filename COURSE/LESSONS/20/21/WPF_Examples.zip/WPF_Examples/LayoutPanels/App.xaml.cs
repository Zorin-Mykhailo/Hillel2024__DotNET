﻿using System.Windows;

namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}

}
