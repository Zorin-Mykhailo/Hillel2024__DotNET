namespace Content
{
	/// <summary>
	/// Interaction logic for TabTest.xaml
	/// </summary>

	public partial class TabTest : System.Windows.Window
	{

		public TabTest()
		{
			InitializeComponent();
		}

	}
}