namespace Content
{
	/// <summary>
	/// Interaction logic for MultiDirectionExpanders.xaml
	/// </summary>

	public partial class MultiDirectionExpanders : System.Windows.Window
	{

		public MultiDirectionExpanders()
		{
			InitializeComponent();
		}

	}
}