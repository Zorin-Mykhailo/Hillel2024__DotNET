namespace Styles
{
	/// <summary>
	/// Interaction logic for StyleInheritance.xaml
	/// </summary>

	public partial class StyleInheritance : System.Windows.Window
	{

		public StyleInheritance()
		{
			InitializeComponent();
		}

	}
}