namespace Styles
{
	/// <summary>
	/// Interaction logic for ReuseFontWithStyles.xaml
	/// </summary>

	public partial class ReuseFontWithStyles : System.Windows.Window
	{

		public ReuseFontWithStyles()
		{
			InitializeComponent();
		}

	}
}