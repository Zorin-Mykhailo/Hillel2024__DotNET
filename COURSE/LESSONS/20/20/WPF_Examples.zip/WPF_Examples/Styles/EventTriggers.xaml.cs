namespace Styles
{
	/// <summary>
	/// Interaction logic for EventTriggers.xaml
	/// </summary>

	public partial class EventTriggers : System.Windows.Window
	{

		public EventTriggers()
		{
			InitializeComponent();
		}

	}
}