namespace ClassicControls
{
	/// <summary>
	/// Interaction logic for RadioButtonGroups.xaml
	/// </summary>

	public partial class RadioButtonGroups : System.Windows.Window
	{

		public RadioButtonGroups()
		{
			InitializeComponent();
		}

	}
}