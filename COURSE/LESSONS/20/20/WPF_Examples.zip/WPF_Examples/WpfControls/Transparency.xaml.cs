namespace ClassicControls
{
	/// <summary>
	/// Interaction logic for ForegroundBackground.xaml
	/// </summary>

	public partial class Transparency : System.Windows.Window
	{

		public Transparency()
		{
			InitializeComponent();
		}

	}
}