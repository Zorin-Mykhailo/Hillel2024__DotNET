namespace ClassicControls
{
	/// <summary>
	/// Interaction logic for IndeterminateProgressBar.xaml
	/// </summary>

	public partial class IndeterminateProgressBar : System.Windows.Window
	{

		public IndeterminateProgressBar()
		{
			InitializeComponent();
		}

	}
}