namespace ClassicControls
{
	/// <summary>
	/// Interaction logic for ComboBoxTest.xaml
	/// </summary>

	public partial class ComboBoxTest : System.Windows.Window
	{

		public ComboBoxTest()
		{
			InitializeComponent();
		}

	}
}