namespace DrawingIn3D
{
	/// <summary>
	/// Interaction logic for Materials.xaml
	/// </summary>

	public partial class AnimatedRing : System.Windows.Window
	{

		public AnimatedRing()
		{
			InitializeComponent();
		}

	}
}