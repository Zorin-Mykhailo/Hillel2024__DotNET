namespace DrawingIn3D
{
	/// <summary>
	/// Interaction logic for OneTriangleMesh.xaml
	/// </summary>

	public partial class OneTriangleMesh : System.Windows.Window
	{

		public OneTriangleMesh()
		{
			InitializeComponent();
		}

	}
}