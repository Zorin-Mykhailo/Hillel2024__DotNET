﻿using System.Windows;
using System.Windows.Input;

namespace SecondExample.Commands
{
	public class CommandReference : Freezable, ICommand
	{
		public CommandReference()
		{
		}

// public static readonly DependencyProperty CommandProperty - это объявление статического поля,
// которое будет хранить идентификатор свойства зависимостей.Оно должно быть public,
// чтобы быть доступным извне, static, так как связано с типом, а не с экземпляром, и readonly,
// потому что идентификатор свойства после регистрации не должен изменяться.
//DependencyProperty.Register - это метод, который регистрирует новое свойство зависимостей.
//Он возвращает экземпляр DependencyProperty, который является идентификатором свойства зависимостей1.
//"Command" - это имя свойства зависимостей. Оно используется в XAML и коде для доступа к свойству.
//typeof(ICommand) - указывает тип данных, которым будет свойство.В данном случае это интерфейс ICommand,
//который обычно используется для команд в паттерне MVVM.
//typeof(CommandReference) - это тип, который владеет свойством, то есть класс, в котором это свойство будет использоваться.
//new PropertyMetadata(new PropertyChangedCallback(OnCommandChanged)) - это метаданные для свойства.
//В данном случае они содержат обратный вызов OnCommandChanged, который будет вызван каждый раз, когда свойство изменяется.
//Это позволяет реагировать на изменения свойства, например, для обновления пользовательского интерфейса или других связанных действий.

		public static readonly DependencyProperty CommandProperty = DependencyProperty.Register("Command", typeof(ICommand), typeof(CommandReference), new PropertyMetadata(new PropertyChangedCallback(OnCommandChanged)));

		public ICommand Command
		{
			get { return (ICommand)GetValue(CommandProperty); }
			set { SetValue(CommandProperty, value); }
		}

		#region ICommand Members

		public bool CanExecute(object parameter)
		{
			if (Command != null)
				return Command.CanExecute(parameter);
			return false;
		}

		public void Execute(object parameter)
		{
			Command.Execute(parameter);
		}

		public event EventHandler CanExecuteChanged;

		private static void OnCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			CommandReference commandReference = d as CommandReference;

			if (e.OldValue is ICommand oldCommand)
			{
				oldCommand.CanExecuteChanged -= commandReference.CanExecuteChanged;
			}
			if (e.NewValue is ICommand newCommand)
			{
				newCommand.CanExecuteChanged += commandReference.CanExecuteChanged;
			}
		}

		#endregion

		#region Freezable

		protected override Freezable CreateInstanceCore()
		{
			throw new NotImplementedException();
		}

// В WPF, Freezable — это особый тип объекта, который может находиться в двух состояниях: фиксированном и нефиксированном.
// В нефиксированном состоянии объект Freezable ведет себя как обычный объект, который можно изменять.Однако, когда он фиксирован,
// его изменить уже нельзя.

//Фиксация объекта Freezable может повысить его производительность,
//так как в этом состоянии он не требует ресурсов на уведомления об изменениях.Фиксированные объекты Freezable
//могут также совместно использоваться разными потоками, что невозможно с нефиксированными объектами.

//Примеры объектов класса Freezable включают кисти, ручки, преобразования, геометрии и анимации.
//Эти объекты часто связаны с подсистемой графики WPF и используются
//для оптимизации производительности приложений, работающих с графикой.

		#endregion
	}
}
