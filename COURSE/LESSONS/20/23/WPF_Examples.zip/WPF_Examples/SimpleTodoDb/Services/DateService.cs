﻿namespace SimpleTodoDb.Services
{
	public interface IDateService
	{
		string FormattedDate { get; }
	}

	public class DateService : IDateService
	{
		public string FormattedDate => $"Today: {DateTime.Now:dd.MM.yyyy}";
	}
}
