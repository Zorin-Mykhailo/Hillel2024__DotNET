﻿using Microsoft.EntityFrameworkCore;
using SimpleTodoDb.Commands;
using SimpleTodoDb.Models;
using SimpleTodoDb.Views;
using System.Collections.ObjectModel;

namespace SimpleTodoDb.ViewModels
{
	public class ApplicationViewModel
	{
		private readonly ApplicationContext _context;
		private readonly MainWindow _mainWindow;

		private RelayCommand? addCommand;
		private RelayCommand? editCommand;
		private RelayCommand? deleteCommand;

		public ObservableCollection<TodoItem> TodoItems { get; set; }

		public ApplicationViewModel(ApplicationContext context, MainWindow mainWindow)
		{
			_context = context;
			_context.TodoItems.Load();
			TodoItems = _context.TodoItems.Local.ToObservableCollection();
			_mainWindow = mainWindow;
		}

		public RelayCommand AddCommand
		{
			get
			{
				return addCommand ??= new RelayCommand((o) =>
				  {
					  TodoItemWindow todoItemWindow = new(new TodoItem())
					  {
						  Owner = _mainWindow
					  };
					  todoItemWindow.ShowDialog();

					  if (todoItemWindow.DialogResult == true)
					  {
						  TodoItem todoItem = todoItemWindow.TodoItem;
						  _context.TodoItems.Add(todoItem);
						  _context.SaveChanges();
					  }
				  });
			}
		}

		public RelayCommand EditCommand
		{
			get
			{
				return editCommand ??= new RelayCommand((selectedItem) =>
				  {
					  if (selectedItem is not TodoItem todoItem) return;

					  var vm = new TodoItem
					  {
						  Id = todoItem.Id,
						  Title = todoItem.Title,
						  Description = todoItem.Description
					  };

					  TodoItemWindow todoItemWindow = new(vm)
					  {
						  Owner = _mainWindow
					  };
					  todoItemWindow.ShowDialog();

					  if (todoItemWindow.DialogResult == true)
					  {
						  todoItem.Title = todoItemWindow.TodoItem.Title;
						  todoItem.Description = todoItemWindow.TodoItem.Description;
						  _context.Entry(todoItem).State = EntityState.Modified;
						  _context.SaveChanges();
					  }
				  });
			}
		}

		public RelayCommand DeleteCommand
		{
			get
			{
				return deleteCommand ??= new RelayCommand((selectedItem) =>
				  {
					  if (selectedItem is not TodoItem todoItem) return;

					  _context.TodoItems.Remove(todoItem);
					  _context.SaveChanges();
				  });
			}
		}
	}
}
