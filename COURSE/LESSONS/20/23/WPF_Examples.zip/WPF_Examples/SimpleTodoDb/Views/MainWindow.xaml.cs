﻿using SimpleTodoDb.Models;
using SimpleTodoDb.Services;
using SimpleTodoDb.ViewModels;
using System.Windows;

namespace SimpleTodoDb.Views
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private readonly IDateService _dateService;
		private readonly ApplicationContext _context;

		public MainWindow(IDateService dateService, ApplicationContext context)
		{
			_dateService = dateService;
			_context = context;

			InitializeComponent();

			MyMainWindow.Title = _dateService.FormattedDate;

			DataContext = new ApplicationViewModel(_context, this);
		}
	}
}