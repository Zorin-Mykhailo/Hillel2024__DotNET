﻿using SimpleTodoDb.Models;
using System.Windows;

namespace SimpleTodoDb.Views
{
	/// <summary>
	/// Interaction logic for TodoItemWindow.xaml
	/// </summary>
	public partial class TodoItemWindow : Window
	{
		public TodoItem TodoItem { get; set; }

		public TodoItemWindow(TodoItem todoItem)
		{
			InitializeComponent();

			TodoItem = todoItem;
			DataContext = TodoItem;
		}

		void Accept_Click(object sender, RoutedEventArgs e)
		{
			DialogResult = true;
		}
	}
}
