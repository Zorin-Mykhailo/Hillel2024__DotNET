﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace SimpleTodoDb.Models
{
	public class TodoItem : INotifyPropertyChanged
	{
		public int Id { get; set; }

		string? title;
		string? description;

		public string? Title
		{
			get { return title; }
			set
			{
				title = value;
				OnPropertyChanged("Title");
			}
		}

		public string? Description
		{
			get { return description; }
			set
			{
				description = value;
				OnPropertyChanged("Description");
			}
		}

		public event PropertyChangedEventHandler? PropertyChanged;
		public void OnPropertyChanged([CallerMemberName] string? prop = "")
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
		}
	}
}
