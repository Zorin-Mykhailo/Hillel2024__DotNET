﻿using Microsoft.EntityFrameworkCore;
using SimpleTodoDb.Models;

namespace SimpleTodoDb
{
	public class ApplicationContext : DbContext
	{
		public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options) { }

		public DbSet<TodoItem> TodoItems { get; set; } = null!;
	}
}
