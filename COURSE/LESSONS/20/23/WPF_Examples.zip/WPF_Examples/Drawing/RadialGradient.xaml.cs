namespace Drawing
{
	/// <summary>
	/// Interaction logic for RadialGradient.xaml
	/// </summary>

	public partial class RadialGradient : System.Windows.Window
	{

		public RadialGradient()
		{
			InitializeComponent();
		}

	}
}