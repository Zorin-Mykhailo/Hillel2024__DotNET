namespace Drawing
{
	/// <summary>
	/// Interaction logic for RotateShape.xaml
	/// </summary>

	public partial class RotateShape : System.Windows.Window
	{

		public RotateShape()
		{
			InitializeComponent();
		}

	}
}