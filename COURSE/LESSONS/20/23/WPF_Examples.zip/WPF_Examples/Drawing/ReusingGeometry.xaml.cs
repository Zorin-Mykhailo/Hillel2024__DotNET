namespace Drawing
{
	/// <summary>
	/// Interaction logic for ReusingGeometry.xaml
	/// </summary>

	public partial class ReusingGeometry : System.Windows.Window
	{

		public ReusingGeometry()
		{
			InitializeComponent();
		}

	}
}