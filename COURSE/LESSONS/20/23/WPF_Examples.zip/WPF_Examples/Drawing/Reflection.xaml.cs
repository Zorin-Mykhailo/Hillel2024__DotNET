namespace Drawing
{
	/// <summary>
	/// Interaction logic for Reflection.xaml
	/// </summary>

	public partial class Reflection : System.Windows.Window
	{

		public Reflection()
		{
			InitializeComponent();
		}

	}
}