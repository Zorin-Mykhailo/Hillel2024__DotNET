namespace Drawing
{
	/// <summary>
	/// Interaction logic for LineJoins.xaml
	/// </summary>

	public partial class LineJoins : System.Windows.Window
	{

		public LineJoins()
		{
			InitializeComponent();
		}

	}
}