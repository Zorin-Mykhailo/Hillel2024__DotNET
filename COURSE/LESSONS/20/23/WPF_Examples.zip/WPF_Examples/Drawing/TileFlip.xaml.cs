namespace Drawing
{
	/// <summary>
	/// Interaction logic for Tiles.xaml
	/// </summary>

	public partial class TileFlip : System.Windows.Window
	{

		public TileFlip()
		{
			InitializeComponent();
		}

	}
}