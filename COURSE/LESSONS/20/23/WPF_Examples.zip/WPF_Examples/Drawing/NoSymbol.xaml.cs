namespace Drawing
{
	/// <summary>
	/// Interaction logic for NoSymbol.xaml
	/// </summary>

	public partial class NoSymbol : System.Windows.Window
	{

		public NoSymbol()
		{
			InitializeComponent();
		}

	}
}