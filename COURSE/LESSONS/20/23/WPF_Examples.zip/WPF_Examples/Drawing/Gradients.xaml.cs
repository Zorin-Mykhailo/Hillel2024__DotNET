namespace Drawing
{
	/// <summary>
	/// Interaction logic for Gradients.xaml
	/// </summary>

	public partial class Gradients : System.Windows.Window
	{

		public Gradients()
		{
			InitializeComponent();
		}

	}
}