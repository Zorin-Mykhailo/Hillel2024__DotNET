namespace Drawing
{
	/// <summary>
	/// Interaction logic for RotateElement.xaml
	/// </summary>

	public partial class RotateElement : System.Windows.Window
	{

		public RotateElement()
		{
			InitializeComponent();
		}

	}
}