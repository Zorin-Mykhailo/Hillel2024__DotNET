namespace Drawing
{
	/// <summary>
	/// Interaction logic for TileTypes.xaml
	/// </summary>

	public partial class TileTypes : System.Windows.Window
	{

		public TileTypes()
		{
			InitializeComponent();
		}

	}
}