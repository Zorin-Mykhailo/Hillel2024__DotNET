namespace Animation
{
	/// <summary>
	/// Interaction logic for AnimateRadialGradient.xaml
	/// </summary>

	public partial class AnimateRadialGradient : System.Windows.Window
	{

		public AnimateRadialGradient()
		{
			InitializeComponent();
		}

	}
}