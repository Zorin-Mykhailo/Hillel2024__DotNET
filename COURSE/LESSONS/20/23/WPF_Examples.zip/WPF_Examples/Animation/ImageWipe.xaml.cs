namespace Animation
{
	/// <summary>
	/// Interaction logic for ImageWipe.xaml
	/// </summary>

	public partial class ImageWipe : System.Windows.Window
	{

		public ImageWipe()
		{
			InitializeComponent();
		}

	}
}