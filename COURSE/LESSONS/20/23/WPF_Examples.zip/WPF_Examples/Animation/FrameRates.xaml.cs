namespace Animation
{
	/// <summary>
	/// Interaction logic for FrameRates.xaml
	/// </summary>

	public partial class FrameRates : System.Windows.Window
	{

		public FrameRates()
		{
			InitializeComponent();


		}

	}
}