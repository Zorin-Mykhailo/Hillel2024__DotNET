namespace ClassicControls
{
	/// <summary>
	/// Interaction logic for Tooltips.xaml
	/// </summary>

	public partial class Tooltips : System.Windows.Window
	{

		public Tooltips()
		{
			InitializeComponent();
		}

	}
}