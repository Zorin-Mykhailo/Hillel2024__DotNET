namespace Content
{
	/// <summary>
	/// Interaction logic for ExpandableContent.xaml
	/// </summary>

	public partial class ExpandableContent : System.Windows.Window
	{

		public ExpandableContent()
		{
			InitializeComponent();
		}

	}
}