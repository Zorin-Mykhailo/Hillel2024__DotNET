namespace Content
{
	/// <summary>
	/// Interaction logic for SimpleBorder.xaml
	/// </summary>

	public partial class SimpleBorder : System.Windows.Window
	{

		public SimpleBorder()
		{
			InitializeComponent();
		}

	}
}