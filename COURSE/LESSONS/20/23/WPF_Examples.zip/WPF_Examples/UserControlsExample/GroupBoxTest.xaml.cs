namespace Content
{
	/// <summary>
	/// Interaction logic for GroupBoxTest.xaml
	/// </summary>

	public partial class GroupBoxTest : System.Windows.Window
	{

		public GroupBoxTest()
		{
			InitializeComponent();
		}

	}
}