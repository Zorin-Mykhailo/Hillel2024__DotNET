namespace Styles
{
	/// <summary>
	/// Interaction logic for SimpleTriggers.xaml
	/// </summary>

	public partial class SimpleTriggers : System.Windows.Window
	{

		public SimpleTriggers()
		{
			InitializeComponent();
		}

	}
}