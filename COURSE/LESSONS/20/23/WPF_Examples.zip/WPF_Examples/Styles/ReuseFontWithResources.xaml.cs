namespace Styles
{
	/// <summary>
	/// Interaction logic for ReuseFontWithResources.xaml
	/// </summary>

	public partial class ReuseFontWithResources : System.Windows.Window
	{

		public ReuseFontWithResources()
		{
			InitializeComponent();
		}

	}
}