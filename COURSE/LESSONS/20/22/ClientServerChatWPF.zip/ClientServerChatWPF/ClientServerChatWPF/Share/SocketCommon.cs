﻿using System.Net;
using System.Threading;

namespace Share
{
    public delegate void LogUIDelegate(string message);

    public class SocketCommon
    {
        public LogUIDelegate logFunction;
        protected readonly SynchronizationContext syncContext = SynchronizationContext.Current;

        protected virtual void Log(string message)
        {
            if(logFunction != null)
            {
				// SynchronizationContext.Current используется для захвата текущего контекста синхронизации,
                // который является контекстом UI.
				// Затем, после выполнения асинхронной операции, используется метод Post
				// для безопасного обновления пользовательского интерфейса в главном потоке
				if (syncContext == SynchronizationContext.Current){
                    logFunction(message);
                }
                else
                {
                    syncContext?.Post(x => logFunction(message), null);
                }
            }
        }

        protected virtual string AddLogHeader(IPEndPoint socket)
        {
            return "/" + socket?.Address.ToString() + ":" + socket?.Port.ToString() + "/ ";
        }
    }
}

// Класс SynchronizationContext в C# представляет собой механизм, который позволяет управлять контекстом синхронизации
// для различных моделей синхронизации.
// Он играет ключевую роль в управлении потоками выполнения кода, особенно в многопоточных и асинхронных приложениях.

//Суть SynchronizationContext:

//- SynchronizationContext обеспечивает базовую функциональность для распространения контекста синхронизации
//в различных моделях синхронизации.
//- Он позволяет коду, который должен быть выполнен в определенном контексте (например, в главном потоке UI),
//быть правильно направленным.

//Как работает SynchronizationContext:

//- Когда выполняется асинхронная операция, SynchronizationContext текущего потока может быть захвачен
//и использован для выполнения кода обратно в этом потоке.
//- Это особенно важно для GUI-приложений, где изменения интерфейса пользователя должны быть выполнены в главном потоке.
//- SynchronizationContext предоставляет методы Post и Send, которые позволяют асинхронно
//или синхронно отправлять делегаты для выполнения в контексте, связанном с SynchronizationContext
