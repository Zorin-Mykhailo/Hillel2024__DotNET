namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for TheUniformGrid.xaml
	/// </summary>

	public partial class TheUniformGrid : System.Windows.Window
	{

		public TheUniformGrid()
		{
			InitializeComponent();
		}

	}
}