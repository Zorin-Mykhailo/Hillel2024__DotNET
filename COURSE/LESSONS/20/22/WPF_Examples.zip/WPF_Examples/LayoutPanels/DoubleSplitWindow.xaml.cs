namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for SplitWindow.xaml
	/// </summary>

	public partial class DoubleSplitWindow : System.Windows.Window
	{

		public DoubleSplitWindow()
		{
			InitializeComponent();
		}

	}
}