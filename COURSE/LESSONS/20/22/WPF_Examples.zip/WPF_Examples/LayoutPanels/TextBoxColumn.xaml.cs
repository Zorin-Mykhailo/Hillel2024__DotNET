namespace LayoutPanels
{
	/// <summary>
	/// Interaction logic for TextBoxColumn.xaml
	/// </summary>

	public partial class TextBoxColumn : System.Windows.Window
	{

		public TextBoxColumn()
		{
			InitializeComponent();
		}

	}
}