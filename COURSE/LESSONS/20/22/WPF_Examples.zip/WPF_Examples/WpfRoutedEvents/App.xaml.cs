﻿using System.Windows;

namespace WpfRoutedEvents
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}

}
