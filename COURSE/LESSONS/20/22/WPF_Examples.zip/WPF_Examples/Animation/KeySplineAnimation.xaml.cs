namespace Animation
{
	/// <summary>
	/// Interaction logic for KeySplineAnimation.xaml
	/// </summary>

	public partial class KeySplineAnimation : System.Windows.Window
	{

		public KeySplineAnimation()
		{
			InitializeComponent();
		}

	}
}