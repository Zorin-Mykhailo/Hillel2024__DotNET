namespace Animation
{
	/// <summary>
	/// Interaction logic for ExpandElement.xaml
	/// </summary>

	public partial class ExpandElement : System.Windows.Window
	{

		public ExpandElement()
		{
			InitializeComponent();
		}

	}
}