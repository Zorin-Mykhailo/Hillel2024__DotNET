namespace Animation
{
	/// <summary>
	/// Interaction logic for AnimateVisual.xaml
	/// </summary>

	public partial class AnimateVisual : System.Windows.Window
	{

		public AnimateVisual()
		{
			InitializeComponent();
		}

	}
}