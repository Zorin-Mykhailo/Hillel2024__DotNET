namespace DrawingIn3D
{
	/// <summary>
	/// Interaction logic for Materials.xaml
	/// </summary>

	public partial class TrackballRing : System.Windows.Window
	{

		public TrackballRing()
		{
			InitializeComponent();
		}

	}
}