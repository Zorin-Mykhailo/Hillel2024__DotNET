namespace DrawingIn3D
{
	/// <summary>
	/// Interaction logic for _DPerson.xaml
	/// </summary>

	public partial class PersonIn3D : System.Windows.Window
	{

		public PersonIn3D()
		{
			InitializeComponent();
		}

	}
}