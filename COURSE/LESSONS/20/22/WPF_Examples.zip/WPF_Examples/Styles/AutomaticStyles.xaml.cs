namespace Styles
{
	/// <summary>
	/// Interaction logic for AutomaticStyles.xaml
	/// </summary>

	public partial class AutomaticStyles : System.Windows.Window
	{

		public AutomaticStyles()
		{
			InitializeComponent();
		}

	}
}