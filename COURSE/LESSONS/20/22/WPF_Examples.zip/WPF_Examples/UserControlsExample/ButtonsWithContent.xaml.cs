namespace Content
{
	/// <summary>
	/// Interaction logic for ButtonsWithContent.xaml
	/// </summary>

	public partial class ButtonsWithContent : System.Windows.Window
	{

		public ButtonsWithContent()
		{
			InitializeComponent();
		}

	}
}