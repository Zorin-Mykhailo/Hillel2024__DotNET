﻿using System.Windows;

namespace NotepadSimpleClone
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}

}
