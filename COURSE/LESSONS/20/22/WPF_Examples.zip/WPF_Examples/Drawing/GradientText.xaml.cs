namespace Drawing
{
	/// <summary>
	/// Interaction logic for GradientText.xaml
	/// </summary>

	public partial class GradientText : System.Windows.Window
	{

		public GradientText()
		{
			InitializeComponent();
		}

	}
}