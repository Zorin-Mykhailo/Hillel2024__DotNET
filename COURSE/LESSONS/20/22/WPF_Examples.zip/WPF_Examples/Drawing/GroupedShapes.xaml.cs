namespace Drawing
{
	/// <summary>
	/// Interaction logic for GroupedShapes.xaml
	/// </summary>

	public partial class GroupedShapes : System.Windows.Window
	{

		public GroupedShapes()
		{
			InitializeComponent();
		}

	}
}