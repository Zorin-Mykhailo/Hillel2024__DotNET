namespace Drawing
{
	/// <summary>
	/// Interaction logic for Viewbox.xaml
	/// </summary>

	public partial class ViewboxResize : System.Windows.Window
	{

		public ViewboxResize()
		{
			InitializeComponent();
		}

	}
}