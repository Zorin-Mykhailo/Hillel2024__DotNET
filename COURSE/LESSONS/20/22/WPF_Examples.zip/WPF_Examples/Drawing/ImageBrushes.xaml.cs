namespace Drawing
{
	/// <summary>
	/// Interaction logic for ImageBrushes.xaml
	/// </summary>

	public partial class ImageBrushes : System.Windows.Window
	{

		public ImageBrushes()
		{
			InitializeComponent();
		}

	}
}