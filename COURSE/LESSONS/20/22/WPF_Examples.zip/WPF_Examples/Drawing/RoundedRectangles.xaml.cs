namespace Drawing
{
	/// <summary>
	/// Interaction logic for RoundedRectangles.xaml
	/// </summary>

	public partial class RoundedRectangles : System.Windows.Window
	{

		public RoundedRectangles()
		{
			InitializeComponent();
		}

	}
}