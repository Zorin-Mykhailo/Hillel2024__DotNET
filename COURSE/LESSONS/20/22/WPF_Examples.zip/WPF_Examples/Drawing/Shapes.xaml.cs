namespace Drawing
{
	/// <summary>
	/// Interaction logic for Shapes.xaml
	/// </summary>

	public partial class Shapes : System.Windows.Window
	{

		public Shapes()
		{
			InitializeComponent();
		}

	}
}