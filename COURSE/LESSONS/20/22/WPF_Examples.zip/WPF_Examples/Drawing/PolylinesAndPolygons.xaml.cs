namespace Drawing
{
	/// <summary>
	/// Interaction logic for Lines.xaml
	/// </summary>

	public partial class PolylinesAndPolygons : System.Windows.Window
	{

		public PolylinesAndPolygons()
		{
			InitializeComponent();
		}

	}
}